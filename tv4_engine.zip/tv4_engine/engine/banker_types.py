# -*- coding: utf-8 -*-
"""
engine/banker_types.py
=======================
Hợp đồng dữ liệu (data contract) cho toàn bộ nhóm.
TV4, TV5, TV6 đều import từ file này để đảm bảo ghép nối không lệch kiểu dữ liệu.

Đây là bản do TV4 tự soạn để engine có thể chạy độc lập ngay, nhưng nếu TV1
đã có sẵn banker_types.py riêng (theo phân công trong đề bài, TV1 là người
chốt hợp đồng dữ liệu), hãy ĐỐI CHIẾU và merge hai bên — tên trường ở đây
được đặt sao cho khớp với thuật ngữ dùng trong file PDF đề tài (Available,
Max, Allocation, Need) để không ai phải đổi tên khi ghép.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class Verdict(Enum):
    """Ba (thực ra bốn) kết cục có thể có của một yêu cầu tài nguyên.

    Theo đúng "bẫy mất điểm" trong đề bài: BA loại từ chối/chờ PHẢI dùng
    ba thông điệp khác nhau, không được gộp chung một câu báo lỗi.
    """
    CAP_PHAT = "CAP_PHAT"                              # đủ điều kiện, cấp ngay
    CHO = "CHO"                                         # thiếu Available, phải chờ
    LOI = "LOI"                                         # xin vượt quá Need đã khai báo
    TU_CHOI_KHONG_AN_TOAN = "TU_CHOI_KHONG_AN_TOAN"     # đủ Available nhưng dẫn tới trạng thái không an toàn


@dataclass
class StepLog:
    """Một dòng nhật ký của thuật toán SafetyCheck — dùng để GUI (TV6) chiếu
    lại từng bước: chọn tiến trình nào, Work trước/sau, và vì sao các tiến
    trình khác bị bỏ qua ở bước đó.
    """
    buoc: int                                  # số thứ tự bước (bắt đầu từ 1)
    work_truoc: List[int]                      # Work trước khi xét bước này
    tien_trinh_chon: Optional[int]              # chỉ số tiến trình được chọn; None nếu không tìm được ai
    work_sau: Optional[List[int]]               # Work sau khi cộng Allocation của tiến trình chọn; None nếu không có ai được chọn
    bo_qua: List[int] = field(default_factory=list)  # danh sách tiến trình bị bỏ qua ở bước này (Need > Work)


@dataclass
class RequestResult:
    """Kết quả trả về của request()/yeu_cau_tai_nguyen()."""
    verdict: Verdict
    thong_diep: str
    chuoi_an_toan: Optional[List[int]] = None
    nhat_ky: List[StepLog] = field(default_factory=list)


class BankerError(Exception):
    """Lỗi dữ liệu đầu vào — luôn có mã lỗi và thông điệp tiếng Việt rõ nghĩa,
    để GUI (TV5) hiển thị trực tiếp cho người dùng mà không cần dịch lại.
    """

    def __init__(self, ma_loi: str, thong_diep: str):
        self.ma_loi = ma_loi
        self.thong_diep = thong_diep
        super().__init__(f"[{ma_loi}] {thong_diep}")
