# -*- coding: utf-8 -*-
"""
engine/banker.py
=================
TV4 — Engine. Cài đặt toàn bộ giải thuật Banker theo đúng mã giả ở mục 03
của file đề tài (do TV3 soạn) và theo hợp đồng dữ liệu ở banker_types.py.

QUY TẮC BẮT BUỘC (ranh giới công việc của TV4):
- KHÔNG được import bất kỳ thư viện giao diện nào (PyQt5, tkinter, ...).
  File này phải chạy được thuần từ dòng lệnh / unit test.
- Mọi hàm public phải trả về đủ dữ liệu để GUI chiếu lại (nhật ký từng
  bước), không chỉ trả về đúng/sai.
- Khi từ chối một yêu cầu vì không an toàn, trạng thái PHẢI được khôi phục
  y hệt trước khi giả lập (rollback nguyên tử) — đây là lỗi hay gặp nhất.

Mỗi hàm bên dưới có alias tiếng Việt (kiem_tra_hop_le, kiem_tra_an_toan,
yeu_cau_tai_nguyen, giai_phong, ket_thuc, tat_ca_chuoi_an_toan) trỏ tới
cùng một cài đặt, để khớp với tên hàm dùng trong file TODO gốc của nhóm
(nếu nhóm bạn dùng tên tiếng Việt) mà không phải viết lại logic hai lần.
"""

import copy
from typing import List, Optional, Tuple

from .banker_types import BankerError, RequestResult, StepLog, Verdict


class BankerState:
    """Đại diện cho một trạng thái cấp phát tài nguyên của hệ thống, với
    n tiến trình và m loại tài nguyên.
    """

    def __init__(
        self,
        available: List[int],
        max_matrix: List[List[int]],
        allocation: List[List[int]],
    ):
        self.n = len(allocation)
        self.m = len(available)
        self.available = list(available)
        self.max = [list(row) for row in max_matrix]
        self.allocation = [list(row) for row in allocation]
        # Need = Max − Allocation, luôn suy ra từ hai ma trận trên, không
        # bao giờ được sửa tay (đúng ranh giới ghi trong đề bài cho TV5).
        self.need = self._tinh_need(self.max, self.allocation)
        # Kiểm tra hợp lệ ngay khi khởi tạo — chặn dữ liệu sai từ gốc.
        self.kiem_tra_hop_le()

    # ------------------------------------------------------------------
    # 0. Hàm phụ trợ
    # ------------------------------------------------------------------
    def _tinh_need(
        self, max_matrix: List[List[int]], allocation: List[List[int]]
    ) -> List[List[int]]:
        return [
            [max_matrix[i][j] - allocation[i][j] for j in range(self.m)]
            for i in range(self.n)
        ]

    # ------------------------------------------------------------------
    # 1. kiem_tra_hop_le — validate dữ liệu đầu vào
    # ------------------------------------------------------------------
    def kiem_tra_hop_le(self) -> bool:
        """Kiểm tra các ràng buộc bắt buộc của mục 03:
        0 <= Allocation[i][j] <= Max[i][j] và Available[j] >= 0.
        Ném BankerError (có mã lỗi + thông điệp tiếng Việt) nếu sai.
        """
        if len(self.max) != self.n or len(self.allocation) != self.n:
            raise BankerError(
                "E01",
                f"Số dòng của Max/Allocation phải bằng số tiến trình n={self.n}",
            )
        if len(self.available) != self.m:
            raise BankerError(
                "E02", f"Available phải có {self.m} phần tử (số loại tài nguyên)"
            )

        for i in range(self.n):
            if len(self.max[i]) != self.m or len(self.allocation[i]) != self.m:
                raise BankerError(
                    "E03", f"Dòng P{i} của Max/Allocation phải có {self.m} cột"
                )
            for j in range(self.m):
                if self.max[i][j] < 0 or self.allocation[i][j] < 0:
                    raise BankerError(
                        "E04", f"Ô P{i}-tài nguyên {j}: không được nhập số âm"
                    )
                if self.allocation[i][j] > self.max[i][j]:
                    raise BankerError(
                        "E05",
                        f"Ô P{i}-tài nguyên {j}: đã cấp {self.allocation[i][j]} "
                        f"nhưng khai báo tối đa {self.max[i][j]}",
                    )

        for j in range(self.m):
            if self.available[j] < 0:
                raise BankerError("E06", f"Available[{j}] không được âm")

        return True

    # ------------------------------------------------------------------
    # 2. kiem_tra_an_toan / is_safe — Thủ tục 1 (SafetyCheck)
    # ------------------------------------------------------------------
    def is_safe(
        self,
        available: Optional[List[int]] = None,
        allocation: Optional[List[List[int]]] = None,
        need: Optional[List[List[int]]] = None,
    ) -> Tuple[bool, Optional[List[int]], List[StepLog]]:
        """SafetyCheck(Available, Allocation, Need) -> (an_toan, chuỗi, nhật_ký)

        Mặc định chạy trên trạng thái hiện tại của self; có thể truyền vào
        một trạng thái giả lập khác (dùng nội bộ bởi request()).
        Trả về nhật ký từng bước để GUI (TV6) chiếu lại, đúng yêu cầu A4.
        """
        work = list(available if available is not None else self.available)
        alloc = allocation if allocation is not None else self.allocation
        nhu_cau = need if need is not None else self.need
        n = len(alloc)

        finish = [False] * n
        chuoi: List[int] = []
        nhat_ky: List[StepLog] = []
        buoc = 0

        while True:
            buoc += 1
            found = None
            bo_qua: List[int] = []

            # Bước 2: tìm i sao cho Finish[i]=False và Need[i] <= Work
            for i in range(n):
                if finish[i]:
                    continue
                if all(nhu_cau[i][j] <= work[j] for j in range(len(work))):
                    found = i
                    break
                bo_qua.append(i)

            if found is None:
                # Không tìm được ai -> sang bước 4, kết thúc vòng lặp
                nhat_ky.append(
                    StepLog(
                        buoc=buoc,
                        work_truoc=list(work),
                        tien_trinh_chon=None,
                        work_sau=None,
                        bo_qua=bo_qua,
                    )
                )
                break

            # Bước 3: Work += Allocation[found]; Finish[found] = True
            work_truoc = list(work)
            for j in range(len(work)):
                work[j] += alloc[found][j]
            finish[found] = True
            chuoi.append(found)
            nhat_ky.append(
                StepLog(
                    buoc=buoc,
                    work_truoc=work_truoc,
                    tien_trinh_chon=found,
                    work_sau=list(work),
                    bo_qua=bo_qua,
                )
            )

        an_toan = all(finish)
        return an_toan, (chuoi if an_toan else None), nhat_ky

    kiem_tra_an_toan = is_safe  # alias tiếng Việt

    # ------------------------------------------------------------------
    # 3. yeu_cau_tai_nguyen / request — Thủ tục 2 (RequestResources)
    # ------------------------------------------------------------------
    def request(self, i: int, req: List[int]) -> RequestResult:
        """RequestResources(i, Request) -> CAP_PHAT | CHO | LOI | TU_CHOI_KHONG_AN_TOAN

        Ba lý do từ chối/chờ dùng BA thông điệp khác nhau (đúng yêu cầu
        "bẫy mất điểm" trong đề bài — không được gộp chung một câu).
        Khi không an toàn: khôi phục nguyên trạng — không sửa self ở nhánh này.
        """
        if i < 0 or i >= self.n:
            raise BankerError("E07", f"Không tồn tại tiến trình P{i}")
        if len(req) != self.m:
            raise BankerError("E08", f"Vector yêu cầu phải có đúng {self.m} phần tử")
        for j in range(self.m):
            if req[j] < 0:
                raise BankerError("E09", f"Yêu cầu tài nguyên {j} không được âm")

        # Bước 1: Request > Need[i] -> LOI
        for j in range(self.m):
            if req[j] > self.need[i][j]:
                return RequestResult(
                    verdict=Verdict.LOI,
                    thong_diep=(
                        f"P{i} xin {req[j]} đơn vị tài nguyên {j} nhưng Need chỉ "
                        f"còn {self.need[i][j]} — xin vượt quá nhu cầu đã khai báo"
                    ),
                )

        # Bước 2: Request > Available -> CHO
        for j in range(self.m):
            if req[j] > self.available[j]:
                return RequestResult(
                    verdict=Verdict.CHO,
                    thong_diep=(
                        f"Hệ thống không đủ tài nguyên {j} đang rảnh "
                        f"({self.available[j]} < {req[j]}) — P{i} phải chờ"
                    ),
                )

        # Bước 3: giả lập cấp phát (KHÔNG đụng vào self cho tới khi biết an toàn)
        available_gia_lap = [self.available[j] - req[j] for j in range(self.m)]
        allocation_gia_lap = copy.deepcopy(self.allocation)
        need_gia_lap = copy.deepcopy(self.need)
        for j in range(self.m):
            allocation_gia_lap[i][j] += req[j]
            need_gia_lap[i][j] -= req[j]

        # Bước 4: chạy SafetyCheck trên trạng thái giả lập
        an_toan, chuoi, nhat_ky = self.is_safe(
            available_gia_lap, allocation_gia_lap, need_gia_lap
        )

        if an_toan:
            # Giữ nguyên trạng thái giả lập -> cấp phát thật
            self.available = available_gia_lap
            self.allocation = allocation_gia_lap
            self.need = need_gia_lap
            return RequestResult(
                verdict=Verdict.CAP_PHAT,
                thong_diep=f"Cấp phát cho P{i} — hệ thống vẫn ở trạng thái an toàn",
                chuoi_an_toan=chuoi,
                nhat_ky=nhat_ky,
            )
        else:
            # Rollback: KHÔNG gán gì vào self -> self giữ nguyên trạng thái cũ
            return RequestResult(
                verdict=Verdict.TU_CHOI_KHONG_AN_TOAN,
                thong_diep=(
                    f"Đủ tài nguyên rảnh nhưng cấp cho P{i} sẽ dẫn tới trạng thái "
                    f"không an toàn — từ chối, khôi phục nguyên trạng"
                ),
                nhat_ky=nhat_ky,
            )

    yeu_cau_tai_nguyen = request  # alias tiếng Việt

    # ------------------------------------------------------------------
    # 4. giai_phong / release — giải phóng một phần tài nguyên
    # ------------------------------------------------------------------
    def giai_phong(self, i: int, rel: List[int]) -> bool:
        if i < 0 or i >= self.n:
            raise BankerError("E07", f"Không tồn tại tiến trình P{i}")
        if len(rel) != self.m:
            raise BankerError("E08", f"Vector giải phóng phải có đúng {self.m} phần tử")
        for j in range(self.m):
            if rel[j] < 0:
                raise BankerError("E09", f"Số lượng giải phóng tài nguyên {j} không được âm")
            if rel[j] > self.allocation[i][j]:
                raise BankerError(
                    "E10",
                    f"P{i} không thể giải phóng {rel[j]} đơn vị tài nguyên {j}, "
                    f"chỉ đang giữ {self.allocation[i][j]}",
                )

        for j in range(self.m):
            self.allocation[i][j] -= rel[j]
            self.need[i][j] += rel[j]
            self.available[j] += rel[j]
        return True

    release = giai_phong  # alias tiếng Anh

    # ------------------------------------------------------------------
    # 5. ket_thuc / finish — tiến trình kết thúc, giải phóng toàn bộ
    # ------------------------------------------------------------------
    def ket_thuc(self, i: int) -> bool:
        if i < 0 or i >= self.n:
            raise BankerError("E07", f"Không tồn tại tiến trình P{i}")
        return self.giai_phong(i, list(self.allocation[i]))

    finish = ket_thuc  # alias tiếng Anh

    # ------------------------------------------------------------------
    # 6. tat_ca_chuoi_an_toan / all_safe_sequences — điểm cộng, quay lui
    # ------------------------------------------------------------------
    def tat_ca_chuoi_an_toan(self) -> List[List[int]]:
        """Liệt kê TẤT CẢ chuỗi an toàn bằng quay lui (backtracking).
        Dùng cho ví dụ nhỏ (demo/báo cáo) — với n lớn (50/100/200 tiến
        trình) KHÔNG gọi hàm này vì độ phức tạp là giai thừa.
        """
        n = self.n
        finish = [False] * n
        ket_qua: List[List[int]] = []

        def quay_lui(work: List[int], chuoi: List[int]) -> None:
            if all(finish):
                ket_qua.append(list(chuoi))
                return
            for i in range(n):
                if finish[i]:
                    continue
                if all(self.need[i][j] <= work[j] for j in range(self.m)):
                    work_moi = [work[j] + self.allocation[i][j] for j in range(self.m)]
                    finish[i] = True
                    chuoi.append(i)
                    quay_lui(work_moi, chuoi)
                    chuoi.pop()
                    finish[i] = False

        quay_lui(list(self.available), [])
        return ket_qua

    all_safe_sequences = tat_ca_chuoi_an_toan  # alias tiếng Anh

    # ------------------------------------------------------------------
    # Alias còn lại để khớp cả hai kiểu tên hàm
    # ------------------------------------------------------------------
    validate = kiem_tra_hop_le
