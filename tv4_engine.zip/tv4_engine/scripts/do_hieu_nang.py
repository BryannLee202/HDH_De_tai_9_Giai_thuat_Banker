# -*- coding: utf-8 -*-
"""
scripts/do_hieu_nang.py
========================
TV4 — script đo thời gian chạy của SafetyCheck (is_safe) khi n tăng dần,
xuất ra CSV để TV7 dùng vẽ biểu đồ đối chiếu với độ phức tạp O(m·n²)
trong chương so sánh (mục 05 của đề bài) — đúng TC10 ở mục 04.

KHÔNG import thư viện giao diện. Chạy thuần dòng lệnh:
    python3 scripts/do_hieu_nang.py

Kết quả ghi vào scripts/ket_qua_hieu_nang.csv với các cột:
    n, m, so_lan_lap, thoi_gian_trung_binh_ms, thoi_gian_nho_nhat_ms
"""

import csv
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.banker import BankerState  # noqa: E402

# Các mốc n theo đúng TC10 trong đề bài, cộng thêm vài mốc nhỏ để thấy rõ xu hướng
CAC_MOC_N = [10, 50, 100, 200]
SO_LOAI_TAI_NGUYEN = 5
SO_LAN_LAP_MOI_MOC = 20


def sinh_trang_thai_ngau_nhien(n: int, m: int) -> BankerState:
    """Sinh một trạng thái hợp lệ ngẫu nhiên với n tiến trình, m loại tài nguyên."""
    max_matrix = [[random.randint(0, 20) for _ in range(m)] for _ in range(n)]
    allocation = [
        [random.randint(0, max_matrix[i][j]) for j in range(m)] for i in range(n)
    ]
    # Available phải đủ lớn để Total = Available + sum(Allocation) hợp lý;
    # sinh Available ngẫu nhiên không âm.
    available = [random.randint(0, 30) for _ in range(m)]
    return BankerState(available, max_matrix, allocation)


def do_thoi_gian_is_safe(n: int, m: int, so_lan: int):
    thoi_gian_list = []
    for _ in range(so_lan):
        trang_thai = sinh_trang_thai_ngau_nhien(n, m)
        bat_dau = time.perf_counter()
        trang_thai.is_safe()
        ket_thuc = time.perf_counter()
        thoi_gian_list.append((ket_thuc - bat_dau) * 1000.0)  # đổi ra ms
    trung_binh = sum(thoi_gian_list) / len(thoi_gian_list)
    nho_nhat = min(thoi_gian_list)
    return trung_binh, nho_nhat


def main():
    duong_dan_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ket_qua_hieu_nang.csv")
    hang = []
    for n in CAC_MOC_N:
        trung_binh, nho_nhat = do_thoi_gian_is_safe(n, SO_LOAI_TAI_NGUYEN, SO_LAN_LAP_MOI_MOC)
        hang.append(
            {
                "n": n,
                "m": SO_LOAI_TAI_NGUYEN,
                "so_lan_lap": SO_LAN_LAP_MOI_MOC,
                "thoi_gian_trung_binh_ms": round(trung_binh, 4),
                "thoi_gian_nho_nhat_ms": round(nho_nhat, 4),
            }
        )
        print(f"n={n:>4}  trung_binh={trung_binh:.4f} ms  nho_nhat={nho_nhat:.4f} ms")

    with open(duong_dan_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["n", "m", "so_lan_lap", "thoi_gian_trung_binh_ms", "thoi_gian_nho_nhat_ms"],
        )
        writer.writeheader()
        writer.writerows(hang)

    print(f"\nĐã ghi kết quả vào: {duong_dan_csv}")


if __name__ == "__main__":
    main()
