# -*- coding: utf-8 -*-
"""
scripts/demo.py
================
Chạy thử engine hoàn toàn từ dòng lệnh trên "Ví dụ chuẩn" (mục 03) và
lần lượt các ca TC01–TC05 (mục 04) — dùng để TV8 đối chiếu kết quả mong
đợi trong bảng test case, hoặc để cả nhóm xem engine hoạt động trước khi
TV5/TV6 ghép giao diện vào.

Chạy: python3 scripts/demo.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.banker import BankerState  # noqa: E402


def in_trang_thai(s: BankerState, tieu_de: str):
    print(f"\n--- {tieu_de} ---")
    print(f"Available = {s.available}")
    for i in range(s.n):
        print(f"P{i}: Allocation={s.allocation[i]}  Need={s.need[i]}")


def main():
    available = [3, 3, 2]
    max_matrix = [[7, 5, 3], [3, 2, 2], [9, 0, 2], [2, 2, 2], [4, 3, 3]]
    allocation = [[0, 1, 0], [2, 0, 0], [3, 0, 2], [2, 1, 1], [0, 0, 2]]

    s = BankerState(available, max_matrix, allocation)
    in_trang_thai(s, "TC01 — Trạng thái ban đầu")
    an_toan, chuoi, nhat_ky = s.is_safe()
    print(f"An toàn: {an_toan} | Chuỗi an toàn: {chuoi}")
    for buoc in nhat_ky:
        if buoc.tien_trinh_chon is not None:
            print(
                f"  Bước {buoc.buoc}: chọn P{buoc.tien_trinh_chon}, "
                f"Work {buoc.work_truoc} -> {buoc.work_sau}, bỏ qua {buoc.bo_qua}"
            )

    print("\n--- TC02: P1 yêu cầu (1,0,2) ---")
    kq = s.request(1, [1, 0, 2])
    print(f"Kết quả: {kq.verdict.value} | {kq.thong_diep}")
    in_trang_thai(s, "Sau TC02")

    print("\n--- TC03: P4 yêu cầu (3,3,0) ---")
    kq = s.request(4, [3, 3, 0])
    print(f"Kết quả: {kq.verdict.value} | {kq.thong_diep}")

    print("\n--- TC04: P0 yêu cầu (0,2,0) ---")
    kq = s.request(0, [0, 2, 0])
    print(f"Kết quả: {kq.verdict.value} | {kq.thong_diep}")
    in_trang_thai(s, "Sau TC04 (phải giống hệt Sau TC02 vì đã rollback)")

    print("\n--- TC05: P2 yêu cầu (7,0,0), Need[2]=(6,0,0) ---")
    kq = s.request(2, [7, 0, 0])
    print(f"Kết quả: {kq.verdict.value} | {kq.thong_diep}")

    print("\n--- Điểm cộng: liệt kê tất cả chuỗi an toàn (từ trạng thái ban đầu) ---")
    s_goc = BankerState(available, max_matrix, allocation)
    tat_ca = s_goc.tat_ca_chuoi_an_toan()
    print(f"Tổng số chuỗi an toàn: {len(tat_ca)}")
    for c in tat_ca:
        print("  ", ["P%d" % i for i in c])


if __name__ == "__main__":
    main()
