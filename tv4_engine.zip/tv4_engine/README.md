# TV4 — Engine giải thuật Banker

Phần bàn giao của TV4 theo mục A4 và mục 03 của đề bài: **Module engine độc
lập + bộ unit test xanh + script đo hiệu năng**. Không có dòng nào import
thư viện giao diện.

## Cấu trúc

```
engine/
  banker_types.py   # hợp đồng dữ liệu: Verdict, StepLog, RequestResult, BankerError
  banker.py          # BankerState — toàn bộ thuật toán
tests/
  test_banker.py      # 17 unit test (>= 15 theo yêu cầu), bám sát TC01-TC10 của đề bài
scripts/
  demo.py             # chạy thử toàn bộ TC01-TC05 + liệt kê chuỗi an toàn, in ra màn hình
  do_hieu_nang.py     # đo thời gian is_safe() với n = 10/50/100/200, xuất CSV cho TV7
```

## Chạy thử

```bash
# Chạy toàn bộ unit test — phải thấy "OK" và 0 lỗi
python3 -m unittest discover -s tests -v

# Xem engine chạy trên Ví dụ chuẩn (mục 03) + toàn bộ TC01-TC05
python3 scripts/demo.py

# Đo hiệu năng, ghi ra scripts/ket_qua_hieu_nang.csv cho TV7
python3 scripts/do_hieu_nang.py
```

Không cần cài thêm thư viện gì — chỉ dùng thư viện chuẩn của Python
(`dataclasses`, `enum`, `copy`, `csv`, `time`, `random`, `unittest`).

## API của `BankerState`

| Hàm (tiếng Anh, theo bảng phân công) | Alias tiếng Việt | Việc làm |
|---|---|---|
| `__init__(available, max_matrix, allocation)` | — | Khởi tạo, tự tính `need`, tự gọi kiểm tra hợp lệ |
| `validate()` | `kiem_tra_hop_le()` | Kiểm tra `0 ≤ Allocation ≤ Max`, không âm; ném `BankerError` nếu sai |
| `is_safe(available=None, allocation=None, need=None)` | `kiem_tra_an_toan()` | Thủ tục 1 (SafetyCheck). Mặc định chạy trên trạng thái hiện tại, có thể truyền trạng thái giả lập. Trả về `(an_toan, chuoi_hoac_None, nhat_ky_tung_buoc)` |
| `request(i, req)` | `yeu_cau_tai_nguyen(i, req)` | Thủ tục 2. Trả về `RequestResult` với `verdict` là một trong `CAP_PHAT / CHO / LOI / TU_CHOI_KHONG_AN_TOAN`, mỗi loại một thông điệp riêng |
| `release(i, rel)` | `giai_phong(i, rel)` | Giải phóng một phần tài nguyên của P*i* |
| `finish(i)` | `ket_thuc(i)` | Giải phóng toàn bộ tài nguyên P*i* đang giữ (coi như kết thúc) |
| `all_safe_sequences()` | `tat_ca_chuoi_an_toan()` | Điểm cộng — liệt kê toàn bộ chuỗi an toàn bằng quay lui. **Không dùng với n lớn (50/100/200)** vì độ phức tạp giai thừa |

Cả hai tên (Anh/Việt) trỏ **cùng một cài đặt** — teammate dùng tên nào cũng
được, không cần sửa code hai lần.

## Cách ghép vào file gốc của nhóm (nếu repo đã có `TODO`)

Nếu file `engine/banker.py` thật của nhóm đã có sẵn khung với các dòng
`TODO`, hãy copy phần thân từng hàm ở trên vào đúng vị trí `TODO` tương
ứng theo thứ tự: `kiem_tra_hop_le` → `kiem_tra_an_toan` →
`yeu_cau_tai_nguyen` → `giai_phong` → `tat_ca_chuoi_an_toan`, rồi chạy lại
bộ test có sẵn của nhóm (`python -m unittest discover -s tests -v`) để
chắc chắn khớp với `tests/test_banker.py` gốc — có thể tên biến/thông điệp
lỗi khác đôi chút, chỉ cần logic đúng.

## Điểm quan trọng khi bảo vệ (liên quan trực tiếp tới engine)

- **Rollback nguyên tử**: trong `request()`, khi trạng thái giả lập không
  an toàn, hàm **không** gán gì vào `self` — vì vậy state gốc không đổi.
  Test `test_06` và `test_12` kiểm chứng bằng `deepcopy` trước/sau.
- **Ba lý do từ chối khác nhau**: `LOI` (xin vượt `Need`), `CHO` (thiếu
  `Available`), `TU_CHOI_KHONG_AN_TOAN` (đủ tài nguyên nhưng không an
  toàn) — ba thông điệp tiếng Việt riêng biệt, đúng "bẫy mất điểm" đề bài
  nêu.
- **Chuỗi an toàn không duy nhất**: `scripts/demo.py` cho thấy Ví dụ chuẩn
  có 16 chuỗi an toàn khác nhau, trong đó có cả `<P1,P3,P4,P2,P0>` (ví dụ
  trong đề) lẫn `<P1,P3,P0,P2,P4>` (thứ tự `is_safe()` thực sự trả về, vì
  thuật toán quét theo chỉ số tăng dần).
- **Trạng thái không an toàn ≠ deadlock**: `is_safe()` chỉ trả lời có tồn
  tại một chuỗi an toàn hay không, không khẳng định hệ thống đang deadlock.
