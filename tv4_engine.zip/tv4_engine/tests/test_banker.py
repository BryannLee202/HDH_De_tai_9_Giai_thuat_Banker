# -*- coding: utf-8 -*-
"""
tests/test_banker.py
=====================
Đặc tả mà TV4 phải thoả. Toàn bộ dữ liệu dùng "Ví dụ chuẩn" ở mục 03 của
file đề tài (5 tiến trình, 3 loại tài nguyên A=10, B=5, C=7), và các ca
TC01–TC10 ở mục 04, để quyển báo cáo (TV3, TV8) và code khớp nhau tuyệt đối.

Chạy: python -m unittest discover -s tests -v
"""

import copy
import unittest

from engine.banker import BankerState
from engine.banker_types import BankerError, Verdict


def vi_du_chuan() -> BankerState:
    """Dựng lại đúng Ví dụ chuẩn trong mục 03 của đề bài."""
    available = [3, 3, 2]
    max_matrix = [
        [7, 5, 3],   # P0
        [3, 2, 2],   # P1
        [9, 0, 2],   # P2
        [2, 2, 2],   # P3
        [4, 3, 3],   # P4
    ]
    allocation = [
        [0, 1, 0],   # P0
        [2, 0, 0],   # P1
        [3, 0, 2],   # P2
        [2, 1, 1],   # P3
        [0, 0, 2],   # P4
    ]
    return BankerState(available, max_matrix, allocation)


def chuoi_hop_le(state: BankerState, chuoi) -> bool:
    """Hàm kiểm chứng độc lập: một chuỗi có phải chuỗi an toàn hợp lệ
    cho trạng thái `state` hay không (dùng để kiểm tra all_safe_sequences
    mà không phụ thuộc vào thứ tự quét bên trong is_safe)."""
    if sorted(chuoi) != list(range(state.n)):
        return False
    work = list(state.available)
    for i in chuoi:
        for j in range(state.m):
            if state.need[i][j] > work[j]:
                return False
        for j in range(state.m):
            work[j] += state.allocation[i][j]
    return True


class TestKhoiTaoVaHopLe(unittest.TestCase):
    """1-2: kiem_tra_hop_le / validate."""

    def test_01_khoi_tao_hop_le_tinh_need_dung(self):
        s = vi_du_chuan()
        self.assertEqual(s.need[0], [7, 4, 3])
        self.assertEqual(s.need[1], [1, 2, 2])
        self.assertEqual(s.need[2], [6, 0, 0])
        self.assertEqual(s.need[3], [0, 1, 1])
        self.assertEqual(s.need[4], [4, 3, 1])

    def test_02_allocation_vuot_max_bi_chan(self):
        with self.assertRaises(BankerError) as ctx:
            BankerState(
                available=[1, 1],
                max_matrix=[[2, 2]],
                allocation=[[3, 0]],  # 3 > 2 -> sai
            )
        self.assertIn("P0", ctx.exception.thong_diep)
        self.assertEqual(ctx.exception.ma_loi, "E05")

    def test_16_gia_tri_am_bi_chan(self):
        with self.assertRaises(BankerError) as ctx:
            BankerState(
                available=[1, 1],
                max_matrix=[[2, 2]],
                allocation=[[-1, 0]],
            )
        self.assertEqual(ctx.exception.ma_loi, "E04")


class TestIsSafe(unittest.TestCase):
    """3, 8, 9, 10: kiem_tra_an_toan / is_safe."""

    def test_03_vi_du_chuan_an_toan_va_dung_chuoi(self):
        s = vi_du_chuan()
        an_toan, chuoi, nhat_ky = s.is_safe()
        self.assertTrue(an_toan)
        self.assertTrue(chuoi_hop_le(s, chuoi))
        # Thuật toán quét theo chỉ số tăng dần mỗi vòng -> chuỗi xác định
        self.assertEqual(chuoi, [1, 3, 0, 2, 4])
        # Nhật ký phải đủ 5 bước tìm được tiến trình (không tính bước dừng)
        buoc_co_chon = [b for b in nhat_ky if b.tien_trinh_chon is not None]
        self.assertEqual(len(buoc_co_chon), 5)

    def test_08_tc06_available_zero_khong_an_toan(self):
        s = BankerState(available=[0, 0], max_matrix=[[5, 5], [3, 3]], allocation=[[0, 0], [0, 0]])
        an_toan, chuoi, _ = s.is_safe()
        self.assertFalse(an_toan)
        self.assertIsNone(chuoi)

    def test_09_tc07_moi_need_bang_khong_an_toan_ngay(self):
        s = BankerState(available=[3], max_matrix=[[2], [1]], allocation=[[2], [1]])
        an_toan, chuoi, _ = s.is_safe()
        self.assertTrue(an_toan)
        self.assertEqual(sorted(chuoi), [0, 1])

    def test_10_tc08_bien_m1_n1_khong_loi_chi_so(self):
        s = BankerState(available=[5], max_matrix=[[3]], allocation=[[1]])
        an_toan, chuoi, _ = s.is_safe()
        self.assertTrue(an_toan)
        self.assertEqual(chuoi, [0])


class TestRequest(unittest.TestCase):
    """4, 5, 6, 7: yeu_cau_tai_nguyen / request — nối tiếp đúng kịch bản TC02-TC05."""

    def test_04_tc02_cap_phat_va_cap_nhat_available(self):
        s = vi_du_chuan()
        kq = s.request(1, [1, 0, 2])
        self.assertEqual(kq.verdict, Verdict.CAP_PHAT)
        self.assertEqual(s.available, [2, 3, 0])
        self.assertEqual(s.allocation[1], [3, 0, 2])
        self.assertEqual(s.need[1], [0, 2, 0])

    def test_05_tc03_cho_vi_thieu_available(self):
        s = vi_du_chuan()
        s.request(1, [1, 0, 2])  # TC02 trước
        kq = s.request(4, [3, 3, 0])
        self.assertEqual(kq.verdict, Verdict.CHO)

    def test_06_tc04_tu_choi_khong_an_toan_va_rollback(self):
        s = vi_du_chuan()
        s.request(1, [1, 0, 2])  # TC02
        truoc_available = copy.deepcopy(s.available)
        truoc_allocation = copy.deepcopy(s.allocation)
        truoc_need = copy.deepcopy(s.need)

        kq = s.request(0, [0, 2, 0])  # TC04

        self.assertEqual(kq.verdict, Verdict.TU_CHOI_KHONG_AN_TOAN)
        # Trạng thái phải được khôi phục y hệt trước khi giả lập
        self.assertEqual(s.available, truoc_available)
        self.assertEqual(s.allocation, truoc_allocation)
        self.assertEqual(s.need, truoc_need)

    def test_07_tc05_loi_xin_vuot_qua_need(self):
        s = vi_du_chuan()
        kq = s.request(2, [7, 0, 0])  # Need[2] = (6,0,0)
        self.assertEqual(kq.verdict, Verdict.LOI)

    def test_12_rollback_khong_lam_hong_doi_tuong_goc(self):
        """Đảm bảo request() không vô tình sửa self ở nhánh bị từ chối,
        kể cả các ma trận lồng nhau (deep copy đúng cách)."""
        s = vi_du_chuan()
        s.request(1, [1, 0, 2])
        ban_sao = copy.deepcopy(s)
        s.request(0, [0, 2, 0])  # bị từ chối vì không an toàn
        self.assertEqual(s.available, ban_sao.available)
        self.assertEqual(s.allocation, ban_sao.allocation)
        self.assertEqual(s.need, ban_sao.need)


class TestGiaiPhongVaKetThuc(unittest.TestCase):
    """13, 14: giai_phong / release, ket_thuc / finish."""

    def test_13_giai_phong_mot_phan(self):
        s = vi_du_chuan()
        s.giai_phong(3, [1, 0, 0])  # P3 đang giữ (2,1,1)
        self.assertEqual(s.allocation[3], [1, 1, 1])
        self.assertEqual(s.need[3], [1, 1, 1])
        self.assertEqual(s.available, [4, 3, 2])

    def test_14_ket_thuc_giai_phong_toan_bo(self):
        s = vi_du_chuan()
        s.finish(3)  # P3 kết thúc, trả lại hết (2,1,1)
        self.assertEqual(s.allocation[3], [0, 0, 0])
        self.assertEqual(s.need[3], s.max[3])
        self.assertEqual(s.available, [5, 4, 3])

    def test_giai_phong_vuot_qua_allocation_bi_chan(self):
        s = vi_du_chuan()
        with self.assertRaises(BankerError):
            s.giai_phong(3, [99, 0, 0])


class TestTatCaChuoiAnToan(unittest.TestCase):
    """15: tat_ca_chuoi_an_toan / all_safe_sequences — điểm cộng."""

    def test_15_liet_ke_nhieu_chuoi_va_deu_hop_le(self):
        s = vi_du_chuan()
        tat_ca = s.tat_ca_chuoi_an_toan()
        self.assertGreater(len(tat_ca), 1)  # chuỗi an toàn không duy nhất
        for chuoi in tat_ca:
            self.assertTrue(chuoi_hop_le(s, chuoi))
        # chuỗi mà is_safe() trả về phải nằm trong tập tất cả chuỗi an toàn
        _, chuoi_don, _ = s.is_safe()
        self.assertIn(chuoi_don, tat_ca)


class TestAliasTenHam(unittest.TestCase):
    """Đảm bảo alias tiếng Anh/Việt trỏ đúng vào cùng một cài đặt."""

    def test_alias_tro_dung_ham(self):
        s = vi_du_chuan()
        self.assertEqual(s.is_safe(), s.kiem_tra_an_toan())
        self.assertTrue(s.validate())


if __name__ == "__main__":
    unittest.main()
